<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Kicks Rack - Manage Products</title>
    <!-- Title icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        .msg {
			left: 35%;
			top: 10%;
			margin-top: -50px;
			padding: 10px; 
			border-radius: 5px; 
			color: #141314; 
			background: #e9b95f; 
			border: 1px solid #f3c324;
			width: 30%;
			text-align: center;
			position: absolute;
		}
    </style>

</head>

<?php 
    require_once 'includes/database-inc.php';
    include_once "header.php";
    require_once 'includes/functions-inc.php';?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Manage Products</h1>
                <p class="mb-4">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam consectetur expedita sunt aspernatur incidunt magni culpa amet commodi minima, libero nostrum dolor delectus velit suscipit voluptate obcaecati. Alias, ratione blanditiis.</p>
                <a href="#" class="btn btn-success btn-icon-split mb-4" data-toggle="modal" data-target="#addProductModal">
                    <span class="text">Add Product</span>
                </a>
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">List of Products Table</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>SKU</th>
                                        <th>Shoe Name</th>
                                        <th>Brand Name</th>
                                        <th>Category</th>
                                        <th>Color</th>
                                        <th>Size</th>
                                        <th>Unit Price</th>
                                        <th>Selling Price</th>
                                        <th>Stocks</th>
                                        <th>Reorder Point</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                <?php
                                    $query ="SELECT tbshoes.shoes_id, categories.category_id, tbshoes.sku, tbshoes.shoe_name, brands.brand_name, categories.category_name, tbshoes.color, tbshoes.size, tbshoes.unit_price, tbshoes.selling_price, tbshoes.stocks, tbshoes.reorder_point FROM ((tbshoes INNER JOIN brands ON tbshoes.brand_id = brands.brand_id) INNER JOIN categories ON tbshoes.category_id = categories.category_id) ORDER BY tbshoes.shoes_id ASC";  
                                    $result = mysqli_query($conn, $query);
                                    
                                    if($result){
                                        foreach($result as $row )  
                                        {  
                                            echo "
                                            
                                            <tr> 
                                                <td>".$row['shoes_id']."</td>  
                                                <td>".$row['sku']."</td> 
                                                <td>".$row['shoe_name']."</td>  
                                                <td>".$row['brand_name']."</td>  
                                                <td>".$row['category_name']."</td>
                                                <td>".$row['color']."</td>  
                                                <td>".$row['size']."</td>
                                                <td>".$row['unit_price']."</td>
                                                <td>".$row['selling_price']."</td>
                                                <td>".$row['stocks']."</td>
                                                <td>".$row['reorder_point']."</td>
                                                <td><button type='button' class ='btn btn-md btn-info editProduct' >Edit</button>
                                                <button type='button' class ='btn btn-md btn-danger deleteProduct pl-3 pr-3'><i class='fa fa-trash fa-sm' aria-hidden='true'></i></button>
                                                </td>
                                                      
                                            </tr>  
                                            ";  
                                        }  
                                    }
                                 
                                ?>  
                               
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

     <!-- Product Modals -->

    <!-- Add Product -->
    <div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white shadow">
                    <h5 class="modal-title" id="addProductModalLabel">Add Product</h5>
                    <button type="button" class="close text-white shadow" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <form method="POST" action="includes/product-inc.php">
                        <div class="modal-body p-4">
                            <div class="form-group">
                                <label for="sku" class="col-form-label">SKU</label>
                                <input type="text" class="form-control form-control-user" name="sku" value='<?php echo uniqid('S0-');?>' readonly>
                            </div>
                            <div class="form-group">
                                <label for="shoe_name" class="col-form-label">Shoe Name: </label>
                                <input type="text" class="form-control form-control-user"  name="shoe_name" required>
                            </div>
                            <div class="form-group">
                                <label for="color" class="col-form-label">Color</label>
                                <input type="text" class="form-control form-control-user"  name="color" required>
                            </div>
                            <div class="form-group">
                                <label for="brand" class="col-form-label mr-3">Brand: </label>
                                <select class="form-select form-control form-select-md mb-3 p-2 border-secondary" name="brand" aria-label=".form-select-lg example">
                                    <option selected>-- Choose brand --</option>
                                    <?php
                                        $query ="SELECT * FROM brands ORDER BY brand_id ASC";  
                                        $result = mysqli_query($conn, $query);   
                                        while($row = mysqli_fetch_array($result))  
                                        {  
                                            echo '  
                                                <option value='.$row["brand_id"].'>'.$row["brand_name"].'</option>';  
                                        }  
                                    ?>  
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="category" class="col-form-label mr-3">Category: </label>
                                <select class="form-select form-control form-select-md mb-3 p-2 border-secondary" name="category" aria-label=".form-select-lg example">
                                    <option selected>-- Choose Category --</option>
                                    <?php
                                        $query ="SELECT * FROM categories ORDER BY category_id ASC";  
                                        $result = mysqli_query($conn, $query);   
                                        while($row = mysqli_fetch_array($result))  
                                        {  
                                            echo '  
                                                <option value='.$row["category_id"].'>'.$row["category_name"].'</option>';  
                                        }  
                                    ?>  
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="size" class="col-form-label mr-3">Size: </label>
                                <select class="form-select form-control form-select-md mb-4 p-2 border-secondary" name="size" aria-label=".form-select-lg example">
                                    <option selected>-- Choose Size --</option>
                                    <option value='6'>6</option>
                                    <option value='6.5'>6.5</option>
                                    <option value='7'>7</option>
                                    <option value='7.5'>7.5</option>
                                    <option value='8'>8</option>
                                    <option value='8.5'>8.5</option>
                                    <option value='9'>9</option>
                                    <option value='9.5'>9.5</option>
                                    <option value='10'>10</option>
                                    <option value='10.5'>10.5</option>
                                    <option value='11'>11</option>
                                    <option value='11.5'>11.5</option>
                                    <option value='12'>12</option>
                                    <option value='13'>13</option>
                                    <option value='14'>14</option>
                                    <option value='15'>15</option>
                                </select>
                            </div>
                            <div class="form-group row">
                                <label for="price" class="col-form-label col-sm-3">Unit Price: </label>
                                <label class="col-form-label col-sm-1"><b>PHP</b> </label>
                                <div class="col-sm-5">
                                    <input type="number" class="form-control form-control-user" name="unit_price" min="0" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="price" class="col-form-label col-sm-3">Selling Price: </label>
                                <label class="col-form-label col-sm-1"><b>PHP</b> </label>
                                <div class="col-sm-5">
                                    <input type="number" class="form-control form-control-user" name="price" min="0" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="stocks" class="col-form-label col-sm-2">Stock: </label>
                                <div class="col-sm-6">
                                    <input type="number" class="form-control form-control-user" name="stocks" min="0" oninput="validity.valid||(value='');" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="reorder" class="col-form-label col-sm-2">Reorder: </label>
                                <div class="col-sm-6">
                                    <input type="number" class="form-control form-control-user" name="reorder" min="0" oninput="validity.valid||(value='');" required>
                                </div>
                            </div>
                        
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
                            <button type="submit" class="btn btn-primary" name="btnAddProduct" value="Save">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>                   
    <!-- End of Add Product -->

    <!-- Edit Product -->
    <div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white shadow">
                    <h5 class="modal-title" id="editProductModalLabel">Edit Product</h5>
                    <button type="button" class="close text-white shadow" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <form method="POST" action="includes/product-inc.php">
                        <div class="modal-body p-4">
                            <div class="form-group">
                                <label for="sku" class="col-form-label">ID</label>
                                <input type="text" class="form-control form-control-user id" name="id" readonly>
                            </div>
                            <div class="form-group">
                                <label for="sku" class="col-form-label">SKU</label>
                                <input type="text" class="form-control form-control-user sku" name="sku" value='<?php echo uniqid('S0-');?>' readonly>
                            </div>
                            <div class="form-group">
                                <label for="shoe_name" class="col-form-label">Shoe Name: </label>
                                <input type="text" class="form-control form-control-user shoe_name"  name="shoe_name" required>
                            </div>
                            <div class="form-group">
                                <label for="color" class="col-form-label">Color</label>
                                <input type="text" class="form-control form-control-user color"  name="color" required>
                            </div>
                            <div class="form-group">
                                <label for="brand" class="col-form-label mr-3">Brand: </label>
                                <select class="form-select form-control form-select-md mb-3 p-2 border-secondary brand" name="brand" aria-label=".form-select-lg example">
                                    <option selected>-- Choose brand --</option>
                                    <?php
                                        $query ="SELECT * FROM brands ORDER BY brand_id ASC";  
                                        $result = mysqli_query($conn, $query);   
                                        while($row = mysqli_fetch_array($result))  
                                        {  
                                            ?>
                                            
                                                <option value="<?php echo $row['brand_name']; ?>"><?php echo $row['brand_name']; ?></option>';  
                                        <?php }  
                                    ?>  
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="category" class="col-form-label mr-3">Category: </label> 
                                <select class="form-select form-control form-select-md mb-3 p-2 border-secondary category" name="category" aria-label=".form-select-lg example">
                                    <option selected>-- Choose Category --</option>
                                    <?php
                                        $query ="SELECT * FROM categories ORDER BY category_id ASC";  
                                        $result = mysqli_query($conn, $query);   
                                        while($row = mysqli_fetch_array($result))  
                                        {  
                                            ?>
                                            
                                                <option value="<?php echo $row['category_name']; ?>"><?php echo $row['category_name']; ?></option>';  
                                        <?php }
                                    ?>  
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="size" class="col-form-label mr-3">Size: </label>
                                <select class="form-select form-control form-select-md mb-4 p-2 border-secondary size" name="size" aria-label=".form-select-lg example">
                                    <option selected>-- Choose Size --</option>
                                    <option value='6'>6</option>
                                    <option value='6.5'>6.5</option>
                                    <option value='7'>7</option>
                                    <option value='7.5'>7.5</option>
                                    <option value='8'>8</option>
                                    <option value='8.5'>8.5</option>
                                    <option value='9'>9</option>
                                    <option value='9.5'>9.5</option>
                                    <option value='10'>10</option>
                                    <option value='10.5'>10.5</option>
                                    <option value='11'>11</option>
                                    <option value='11.5'>11.5</option>
                                    <option value='12'>12</option>
                                    <option value='13'>13</option>
                                    <option value='14'>14</option>
                                    <option value='15'>15</option>
                                </select>
                            </div>
                            <div class="form-group row">
                                <label for="price" class="col-form-label col-sm-3">Unit Price: </label>
                                <label class="col-form-label col-sm-1"><b>PHP</b> </label>
                                <div class="col-sm-5">
                                    <input type="number" class="form-control form-control-user unit_price" name="unit_price" min="0"  required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="price" class="col-form-label col-sm-3">Selling Price: </label>
                                <label class="col-form-label col-sm-1"><b>PHP</b> </label>
                                <div class="col-sm-5">
                                    <input type="number" class="form-control form-control-user price" name="price" min="0" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="stocks" class="col-form-label col-sm-2">Stock: </label>
                                <div class="col-sm-6">
                                    <input type="number" class="form-control form-control-user stocks" name="stocks" min="0" oninput="validity.valid||(value='');" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="reorder" class="col-form-label col-sm-2">Reorder: </label>
                                <div class="col-sm-6">
                                    <input type="number" class="form-control form-control-user reorder" name="reorder"  min ="0" oninput="validity.valid||(value='');" required>
                                </div>
                            </div>
                        
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
                            <button type="submit" class="btn btn-primary" name="btnEditProduct" value="Update">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>                   
    <!-- End of Edit Product -->
    
    <!-- Delete Product Modal -->
    <div class="modal fade" id="deleteProductModal" tabindex="-1" role="dialog" aria-labelledby="deleteProductModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white shadow">
                    <h5 class="modal-title" id="deleteProductModalLabel">Delete User?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="includes/product-inc.php" method="post">
                    <div class="modal-body ml-2"><h5 class="text-center">Are you sure you want to delete this product?</h5>
                        <input type="hidden" class="form-control id" name="id">
                        <div class="form-group row mt-4">
                            <label for="sku" class="col-form-label col-sm-3">SKU: </label> 
                            <div class="col-sm-7">
                                <input type="text" class="form-control sku" name="sku" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="shoe_name" class="col-form-label col-sm-3">Shoe name: </label> 
                            <div class="col-sm-7">
                                <input type="text" class="form-control shoe_name" name="shoe_name" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="color" class="col-form-label col-sm-3">Color: </label> 
                            <div class="col-sm-7">
                                <input type="text" class="form-control color" name="color" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="size" class="col-form-label col-sm-3">Size: </label> 
                            <div class="col-sm-7">
                                <input type="text" class="form-control size" name="size" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <input type="submit" name="btnProductDelete" class="btn btn-primary" value="Yes"></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End of Delete Product Modal-->

    <?php
        if(isset($_GET["error"])){
           if($_GET["error"] == "stmtfailed"){ ?>
                <div class='msg'>
                    <?php echo "Oops! Something went wrong."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "productadded"){ ?>
                <div class='msg'>
                    <?php echo "Product has been added successfully."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "productupdated"){ ?>
                <div class='msg'>
                    <?php echo "Product has been updated successfully."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "productdeleted"){ ?>
                <div class='msg'>
                    <?php echo "Product has been deleted successfully."; ?>          
                </div>
                <?php
            }
        }
    ?>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script>
        $(document).ready(function(){
            $('.editProduct').click(function(){  
                $("#editProductModal").modal('show');
                $tr = $(this).closest('tr');
                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();
                
                console.log(data);
                $('#editProductModal .id').val(data[0]);
                $('#editProductModal .sku').val(data[1]);
                $('#editProductModal .shoe_name').val(data[2]);
                $('#editProductModal .brand').val(data[3]);
                $('#editProductModal .category').val(data[4]);
                $('#editProductModal .color').val(data[5]);
                $('#editProductModal .size').val(data[6]);
                $('#editProductModal .unit_price').val(data[7]);
                $('#editProductModal .price').val(data[8]);
                $('#editProductModal .stocks').val(data[9]);
                $('#editProductModal .reorder').val(data[10]);
              
            });
            $('.deleteProduct').click(function(){  
                $("#deleteProductModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#deleteProductModal .id').val(data[0]);
                $('#deleteProductModal .sku').val(data[1]);
                $('#deleteProductModal .shoe_name').val(data[2]);
                $('#deleteProductModal .color').val(data[5]);
                $('#deleteProductModal .size').val(data[6]);
            });      
          });
    </script>
    <script>
        setTimeout(function() {
            $('.msg').fadeOut('fast');
        }, 3000); // <-- time in milliseconds
    </script>
</body>

</html>