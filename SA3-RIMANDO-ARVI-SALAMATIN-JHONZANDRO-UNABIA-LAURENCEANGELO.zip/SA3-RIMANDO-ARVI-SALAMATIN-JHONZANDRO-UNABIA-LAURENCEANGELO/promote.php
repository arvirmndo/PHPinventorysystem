<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<?php 
    require_once 'includes/database-inc.php';
    include_once "header.php";
    require_once 'includes/functions-inc.php';?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Promote/Change Role</h1>
                <p class="mb-4">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam consectetur expedita sunt aspernatur incidunt magni culpa amet commodi minima, libero nostrum dolor delectus velit suscipit voluptate obcaecati. Alias, ratione blanditiis.</p>
                <a href="#" class="btn btn-success btn-icon-split mb-4" data-toggle="modal" data-target="#addUserModal">
                    <span class="text">Add User</span>
                </a>
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Users Table</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>User ID</th>
                                        <th>Email</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Role</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                <?php
                                    $query ="SELECT tbusers.user_id, tbusers.email, tbusers.firstName, tbusers.lastName, tbusers.gender, tbusers.phoneNumber, tbroles.role_name FROM ((user_role INNER JOIN tbusers ON user_role.user_id = tbusers.user_id) INNER JOIN tbroles ON user_role.role_id = tbroles.role_id) ORDER BY tbusers.user_id DESC";  
                                    $result = mysqli_query($conn, $query);
                                    
                                    if($result){
                                        foreach($result as $row )  
                                        {  
                                            echo "  
                                            <tr>  
                                                    <td>".$row['user_id']."</td>  
                                                    <td>".$row['email']."</td>  
                                                    <td>".$row['firstName']."</td>  
                                                    <td>".$row['lastName']."</td>
                                                    <td>".roleBadge($row['role_name'])."</td>  
                                                    <td><button type='button' class ='btn btn-md btn-info editUser' >Edit</button>
                                                    <button type='button' class ='btn btn-md btn-danger deleteUser w-25'><i class='fa fa-trash fa-sm' aria-hidden='true'></i></button>
                                                    </td>      
                                            </tr>  
                                            ";  
                                        }  
                                    }
                                 
                                ?>  
                               
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script>
        $(document).ready(function(){
            $('.editUser').click(function(){  
                $("#editUserModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#editUserModal .uid').val(data[0]);
                $('#editUserModal .email').val(data[1]);
                $('#editUserModal .firstName').val(data[2]);
                $('#editUserModal .lastName').val(data[3]);
                $("#editUserModal input[name=gender][value=" + data[5] + "]").prop('checked',true);
                $('#editUserModal .phone').val(data[6]);
               
            });
            $('.deleteUser').click(function(){  
                $("#deleteUserModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#deleteUserModal .uid').val(data[0]);
                $('#deleteUserModal .username').val(data[2] + ' ' + data[3]);
               
            });      
          });
    </script>
</body>

</html>