<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Kicks Rack - Purchases </title>
    <!-- Title icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet"> 

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="vendor/jquery-ui/jquery-ui.min.css">
     <link rel="stylesheet" href="vendor/jquery-ui/jquery-ui.theme.css">   
  
</head>

<?php 
    require_once 'includes/database-inc.php';
    include_once "header.php";
    require_once 'includes/functions-inc.php';?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Purchase Orders</h1>
                <p class="mb-4">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam consectetur expedita sunt aspernatur incidunt magni culpa amet commodi minima, libero nostrum dolor delectus velit suscipit voluptate obcaecati. Alias, ratione blanditiis.</p>
                <hr class="sidebar-divider">
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">List of Purchase Orders</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                        <table class = "table table-borderless" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="row g-3">
                                            <div class = "form-group row">
                                                <label for="start-date" class="col-form-label col-auto">Start Date: </label> 
                                                <div class="col-sm-6">
                                                    <input type="text" class ="form-control" name="start-date" id="start" name="start">
                                                </div>
                                            </div>
                                            <div class = "form-group row">
                                                <label for="end-date" class="col-form-label col-auto">End Date: </label> 
                                                <div class="col-sm-6">
                                                    <input type="text" class ="form-control" name="end-date" id="end" name="end">
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                        </tbody>
                    </table>
                            <table class="table table-bordered" id="POdataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>PO ID</th>
                                        <th>SKU</th>
                                        <th>Shoe Name</th>
                                        <th>Color</th>
                                        <th>Size</th>
                                        <th>Unit Price</th>
                                        <th>Ordered Qty</th>
                                        <th>Total Amount</th>
                                        <th>Supplier</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Purchase Status</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                <?php
                                    $query ="SELECT tbpurchase.purchase_id, tbsupplier.supplier_name, tbshoes.sku, tbshoes.shoe_name, tbshoes.color, tbshoes.size, tbshoes.unit_price, tbpurchase.qty, tbpurchase.total_amount, tbpurchase.order_dt, tbpurchase.received_dt, tbpurchase.purchase_status FROM ((tbpurchase INNER JOIN tbshoes ON tbpurchase.shoes_id = tbshoes.shoes_id) INNER JOIN tbsupplier ON tbpurchase.supplier_id = tbsupplier.supplier_id)";  
                                    $result = mysqli_query($conn, $query);
                                    
                                    if($result){
                                        foreach($result as $row )  
                                        {  
                                            echo "
                                            
                                            <tr> 
                                                <td>".$row['purchase_id']."</td>  
                                                <td>".$row['sku']."</td> 
                                                <td>".$row['shoe_name']."</td>  
                                                <td>".$row['color']."</td>  
                                                <td>".$row['size']."</td>
                                                <td>".$row['unit_price']."</td>  
                                                <td>".$row['qty']."</td>
                                                <td>".$row['total_amount']."</td>
                                                <td>".$row['supplier_name']."</td>
                                                <td>".changeDateFormat($row['order_dt'])."</td>
                                                <td>".changeDateFormat($row['received_dt'])."</td>
                                                <td>".$row['purchase_status']."</td>
                                                
                                                      
                                            </tr>  
                                            ";  
                                        }  
                                    }
                                 
                                ?>  
                               
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    
    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>
    <script>
        $(document).ready(function() {
            $.fn.dataTable.ext.search.push(
            function (settings, data, dataIndex) {
                var min = $('#start').datepicker("getDate");
                var max = $('#end').datepicker("getDate");
                var startDate = new Date(data[9]);
                if (min == null && max == null) { return true; }
                if (min == null && startDate <= max) { return true;}
                if (max == null && startDate >= min) {return true;}
                if (startDate <= max && startDate >= min) { return true; }
                return false;
            }
            );
            
            // Event listener to the two range filtering inputs to redraw on input
            
                $( "#start" ).datepicker({
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'yy/m/d',
                    onSelect: function() {
                        table.draw();}
                });
                $( "#end" ).datepicker({
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'yy/m/d',
                    onSelect: function() {
                        table.draw();}
                });

            
            var table = $('#POdataTable').DataTable();

            $('#start, #end').change( function() {
                table.draw();
            } );
        
        } );
    </script>
</html>