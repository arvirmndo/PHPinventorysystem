<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Kicks Rack - Add Sales</title>
    <!-- Title icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
    
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        .msg {
			left: 35%;
			top: 10%;
			margin-top: -50px;
			padding: 10px; 
			border-radius: 5px; 
			color: #141314; 
			background: #e9b95f; 
			border: 1px solid #f3c324;
			width: 30%;
			text-align: center;
			position: absolute;
		}
    </style>
</head>

<?php 
    require_once 'includes/database-inc.php';
    include_once "header.php";
    require_once 'includes/functions-inc.php';?>

            <!-- Begin Page Content -->

            <div class="container-fluid">
                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Add Sales</h1>
                <div class="row">
                    <!-- Pie Chart -->
                    <div class="col-xl-3 col-lg-4">
                        <div class="card shadow mb-4">
                            <!-- Card Header - Dropdown -->
                            <div
                                class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold text-primary">Order Details</h6>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                            <form action="includes/addSales-inc.php" method="post">
                                    <div class="form-group">
                                        <label for="sku" class="col-form-label">Product ID:</label>
                                        <input type="text" class="form-control id" name="id" placeholder="Product ID goes here..." readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="sku" class="col-form-label">SKU</label>
                                        <input type="text" class="form-control sku" name="sku" placeholder="SKU goes here..."readonly>
                                    </div>

                                    <div class="form-group">
                                        <label for="shoe_name" class="col-form-label">Shoe Name</label>
                                        <input type="text" class="form-control shoe_name"  placeholder="Shoe name goes here..." name="shoe_name" readonly>
                                    </div>
                                    <div class = "row">
                                        <div class = "col-sm-6">
                                            <div class="form-group">
                                                <label for="color" class="col-form-label">Color:</label>
                                                <input type="text" class="form-control color"  placeholder="Ex. Blue" name="color" readonly>
                                            </div>
                                        </div>
                                        <div class = "col-sm-6">
                                            <div class="form-group">
                                                <label for="size" class="col-form-label">Size (US):</label>
                                                <input type="text" class="form-control size col-sm-6"  placeholder="Ex. 10" name="size" readonly>
                                            </div>
                                        </div>
                                    </div>
                                        
                                    <div class = "row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="recipient-name" class="col-form-label">In Stocks:</label>
                                                <input type="number" class="form-control instocks " placeholder="0" name="instocks" readonly>
                                            </div>
                                        </div>
                                        <div class = "col-sm-6">
                                            <div class="form-group">
                                                <label for="recipient-name" class="col-form-label">Out Stocks:</label>
                                                <input type="number" class="form-control outstocks" value="0" name="outstocks" min="0" oninput="validity.valid||(value='');" required>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="submit" value= "Order" name="deductStocks" class="btn btn-success btn-user btn-block mt-2 deductStocks">
                                    <input type="button" value= "Reset" name="reset" class="btn btn-secondary btn-user btn-block mt-2 reset">
                                </form>
                            </div>
                        </div>
                    </div>
                     <div class="col-xl-9 col-lg-8" >
                        <!-- DataTales Example -->
                        <div class="card shadow mb-4 ">
                            <div class="card-header py-3 bg-info text-white shadow ">
                                <h6 class="m-0 font-weight-bold">Product Table</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="productDataTable" width="100%" height ="100px" cellspacing="0">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>ID</th>
                                                <th>SKU</th>
                                                <th>Shoe Name</th>
                                                <th>Brand Name</th>
                                                <th>Category</th>
                                                <th>Color</th>
                                                <th>Size</th>
                                                <th>Selling Price</th>
                                                <th>Stocks</th>
                                                <th>Reorder Point</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                    
                                        <tbody>
                                            
                                        <?php
                                            $query ="SELECT tbshoes.shoes_id, categories.category_id, tbshoes.sku, tbshoes.shoe_name, brands.brand_name, categories.category_name, tbshoes.color, tbshoes.size, tbshoes.selling_price, tbshoes.stocks, tbshoes.reorder_point FROM ((tbshoes INNER JOIN brands ON tbshoes.brand_id = brands.brand_id) INNER JOIN categories ON tbshoes.category_id = categories.category_id) ORDER BY tbshoes.shoes_id ASC";  
                                            $result = mysqli_query($conn, $query);
                                            
                                            if($result){
                                                foreach($result as $row )  
                                                {  
                                                    echo "
                                                    
                                                    <tr> 
                                                        <td>".$row['shoes_id']."</td>  
                                                        <td>".$row['sku']."</td> 
                                                        <td>".$row['shoe_name']."</td>  
                                                        <td>".$row['brand_name']."</td>  
                                                        <td>".$row['category_name']."</td>
                                                        <td>".$row['color']."</td>  
                                                        <td>".$row['size']."</td>
                                                        <td>".$row['selling_price']."</td>
                                                        <td>".$row['stocks']."</td>
                                                        <td>".$row['reorder_point']."</td>
                                                        <td><button type='button' class ='btn btn-md btn-success select' > <i class='fas fa-fw fa-check'></i></button>
                                                        </td>   
                                                    </tr>  
                                                    ";  
                                                }  
                                            }
                                        
                                        ?>  
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <?php
        if(isset($_GET["error"])){
            if($_GET["error"] == "stmtfailed"){ ?>
                <div class='msg'>
                    <?php echo "Oops! Something went wrong."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "salesadded"){ ?>
                <div class='msg'>
                    <?php echo "Sales order has been added successfully."; ?>          
                </div>
                <?php
            }
        }
    ?>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script>
        $(document).ready(function(){
            $('#productDataTable').DataTable( {
                "lengthMenu": [[5, 25, 50, -1], [5, 25, 50, "All"]]
            } );
            $('.select').click(function(){  
                $tr = $(this).closest('tr');
                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();
                
                console.log(data);
                $('.id').val(data[0]);
                $('.sku').val(data[1]);
                $('.shoe_name').val(data[2]);
                $('.color').val(data[5]);
                $('.size').val(data[6]);
                $('.instocks').val(data[8]);
              
            });
            $('.reset').click(function(){  
                $('.id').val('');
                $('.sku').val('');
                $('.shoe_name').val('');
                $('.color').val('');
                $('.size').val('');
                $('.instocks').val('');
                $('.outstocks').val('0');
              
            });
            $('form').submit(function(e){  
                var id = $('.id').val();
                var out = parseInt($('.outstocks').val());
                var instock = parseInt($('.instocks').val());

                if(id == ''){
                   alert('Please select an item');
                   e.preventDefault();
               }else if(out === 0){
                   alert('Please input your outstocks');
                   e.preventDefault();
               }else if(instock < out){
                   alert('Insufficient instock quantity');
                   e.preventDefault();
                }
            });      
          });
    </script>
    <script>
        setTimeout(function() {
            $('.msg').fadeOut('fast');
        }, 3000); // <-- time in milliseconds
    </script>
    

</body>

</html>