<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Kicks Rack - Manage Products</title>
    <!-- Title icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<?php 
    require_once 'includes/database-inc.php';
    include_once "header.php";
    require_once 'includes/functions-inc.php';?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Low Stocks Products</h1>
                <p class="mb-4">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam consectetur expedita sunt aspernatur incidunt magni culpa amet commodi minima, libero nostrum dolor delectus velit suscipit voluptate obcaecati. Alias, ratione blanditiis.</p>
             
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">List of Products under Reorder Point </h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>SKU</th>
                                        <th>Shoe Name</th>
                                        <th>Brand Name</th>
                                        <th>Category</th>
                                        <th>Color</th>
                                        <th>Size</th>
                                        <th>Price</th>
                                        <th>Stocks</th>
                                        <th>Reorder Point</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                <?php
                                    $query ="SELECT tbshoes.shoes_id, categories.category_id, tbshoes.sku, tbshoes.shoe_name, brands.brand_name, categories.category_name, tbshoes.color, tbshoes.size, tbshoes.selling_price, tbshoes.stocks, tbshoes.reorder_point FROM ((tbshoes INNER JOIN brands ON tbshoes.brand_id = brands.brand_id) INNER JOIN categories ON tbshoes.category_id = categories.category_id) WHERE tbshoes.stocks <= tbshoes.reorder_point ORDER BY tbshoes.shoes_id ASC";  
                                    $result = mysqli_query($conn, $query);
                                    
                                    if($result){
                                        foreach($result as $row )  
                                        {  
                                            echo "
                                            
                                            <tr> 
                                                <td>".$row['shoes_id']."</td>  
                                                <td>".$row['sku']."</td> 
                                                <td>".$row['shoe_name']."</td>  
                                                <td>".$row['brand_name']."</td>  
                                                <td>".$row['category_name']."</td>
                                                <td>".$row['color']."</td>  
                                                <td>".$row['size']."</td>
                                                <td>".$row['selling_price']."</td>
                                                <td>".$row['stocks']."</td>
                                                <td>".$row['reorder_point']."</td>
                                                <td><a href='purchase.php' class ='btn btn-md btn-info editProduct' >Order now</button>
                                                </td>
                                                      
                                            </tr>  
                                            ";  
                                        }  
                                    }
                                 
                                ?>  
                               
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
</body>

</html>