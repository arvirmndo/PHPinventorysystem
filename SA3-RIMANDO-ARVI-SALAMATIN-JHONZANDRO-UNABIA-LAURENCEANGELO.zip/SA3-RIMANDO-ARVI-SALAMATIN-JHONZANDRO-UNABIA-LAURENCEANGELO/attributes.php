<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<?php include_once "header.php";
require_once 'includes/database-inc.php';?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Manage </h1>
                <p class="mb-4">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet incidunt eos distinctio delectus perspiciatis pariatur blanditiis, suscipit repellat deserunt ex, molestias non unde corrupti cum natus sed repellendus minima culpa.</p>
                <a href="#" class="btn btn-success btn-icon-split mb-4" data-toggle="modal" data-target="#addAttributeModal">
                    <span class="text">Add Attribute</span>
                </a>

                <!-- DataTables Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Attribute ID</th>
                                        <th>Attribute Name</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $query ="SELECT * FROM attributes ORDER BY attribute_id ASC";  
                                    $result = mysqli_query($conn, $query);   
                                    while($row = mysqli_fetch_array($result))  
                                    {  
                                        echo '  
                                        <tr>  
                                                <td>'.$row["attribute_id"].'</td>  
                                                <td>'.$row["attribute_name"].'</td>
                                                <td>'.$row["attribute_desc"].'</td>  
                                                <td><button type="button" class ="btn btn-md btn-info editAttribute" >Edit</button>
                                                <button type="button" class ="btn btn-md btn-danger deleteAttribute">Delete</button>
                                                </td>      
                                        </tr>  
                                        ';  
                                    }  
                                ?>  
                                   
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script>
        $(document).ready(function(){
            $('.editAttribute').click(function(){  
                $("#editAttributeModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#editAttributeModal .attribute_id').val(data[0]);
                $('#editAttributeModal .attribute_name').val(data[1]);
                $('#editAttributeModal .attribute_desc').val(data[2]);
               
            });
            // $('.deleteUser').click(function(){  
            //     $("#deleteUserModal").modal('show');
            //     $tr = $(this).closest('tr');

            //     var data = $tr.children("td").map(function(){
            //         return $(this).text();
            //     }).get();

            //     console.log(data);
            //     $('#deleteUserModal .uid').val(data[0]);
            //     $('#deleteUserModal .username').val(data[2] + ' ' + data[3]);
               
            // });      
          });
    </script>
</body>

</html>