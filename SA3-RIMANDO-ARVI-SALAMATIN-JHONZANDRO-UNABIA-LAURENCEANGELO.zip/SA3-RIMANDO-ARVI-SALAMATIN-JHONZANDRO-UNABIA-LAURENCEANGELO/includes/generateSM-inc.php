<?php
    if(isset($_POST["report"])){
        require_once 'database-inc.php';
        require_once 'functions-inc.php';
        require_once 'SMreport-inc.php';

        $start = date('Y-m-d', strtotime($_POST["start-date"])) ;
        $end = date('Y-m-d', strtotime($_POST["end-date"]));

        generateSM($conn, $start, $end);

    }
