<?php
    require("../vendor/fpdf/fpdf.php");

    class PDF extends FPDF
    {
        function Header()
        {
            $this->Image('../img/favicon.png',10,8,33);
            $this->SetFont('Helvetica','B',16);
            $this->Cell(340,5,'KICKS RACK',0,0,'C');
            $this->Ln(10);
            $this->SetFont('Helvetica','B',14);
            $this->Cell(340,10,'Daily Stock Monitoring Report',0,0,'C');
            $this->Ln();
        }

        function Footer()
        {
            $this->SetXY(300,-15);
            $this->SetFont('Helvetica','I',10);
            $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
            $this->Write (3, 'Created: '.date('M d Y'));
        }
        function HeaderTable(){
            $this->SetFillColor(143, 247, 247);
            $this->SetFont('Arial', 'B', '9');
            
            $this->cell(40, 10, "Date/Time", 1, 0, 'C');
            $this->cell(40, 10, "Stock Control ID", 1, 0, 'C');
            $this->cell(40, 10, "SKU", 1, 0, 'C');
            $this->cell(50, 10, "Shoe Name", 1, 0, 'C');
            $this->cell(30, 10, "Color", 1, 0, 'C');
            $this->cell(30, 10, "Size", 1, 0, 'C');
            $this->cell(30, 10, "Stock In", 1, 0, 'C');
            $this->cell(30, 10, "Stock Out", 1, 0, 'C');
            $this->cell(40, 10, "Action by", 1, 1, 'C');
        }
    }

    function generateSM($conn, $start, $end){
        $sql = "SELECT tbstock_monitoring.stock_control_id, tbshoes.sku, tbshoes.shoe_name, tbshoes.color, tbshoes.size, tbstock_monitoring.stock_in_qty, tbstock_monitoring.stock_out_qty, tbstock_monitoring.date_time, tbstock_monitoring.user_name FROM tbstock_monitoring INNER JOIN tbshoes ON tbstock_monitoring.shoes_id = tbshoes.shoes_id WHERE date_time BETWEEN ? AND ?;";

        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../purchase_report.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $start, $end);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        $pdf = new PDF('p', 'mm' , 'Legal');
        
        $pdf->AddPage('L');
        $pdf->SetFont('Helvetica', '', '12');
        $pdf->Cell(340,10,changeDateFormat($start).' -'.changeDateFormat($end),0,0,'C');
        $pdf->Ln(15);

        $pdf->HeaderTable();
        
        $pdf->SetFont('Arial', '', '9');

        while($row = mysqli_fetch_assoc($resultData)){
            $pdf->cell(40, 10, changeDateFormat($row['date_time']), 1, 0, 'C');
            $pdf->cell(40, 10, $row['stock_control_id'], 1, 0, 'C');
            $pdf->cell(40, 10, $row['sku'], 1, 0, 'C');
            $pdf->cell(50, 10, $row['shoe_name'], 1, 0, 'C');
            $pdf->cell(30, 10, $row['color'], 1, 0, 'C');
            $pdf->cell(30, 10, $row['size'], 1, 0, 'C');
            $pdf->cell(30, 10, $row['stock_in_qty'], 1, 0, 'C');
            $pdf->cell(30, 10, $row['stock_out_qty'], 1, 0, 'C');
            $pdf->cell(40, 10, $row['user_name'], 1, 1, 'C');

        }

        $pdf->Output('example2.pdf','I');
    }