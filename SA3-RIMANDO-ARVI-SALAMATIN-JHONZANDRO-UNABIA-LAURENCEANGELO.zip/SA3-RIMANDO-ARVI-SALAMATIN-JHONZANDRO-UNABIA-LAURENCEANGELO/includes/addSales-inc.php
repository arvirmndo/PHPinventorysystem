<?php
    if(isset($_POST["deductStocks"])){
        session_start();
        $id = $_POST["id"];
        $instocks = $_POST["instocks"];
        $outstocks = $_POST["outstocks"];
        $deduct = $instocks - $outstocks;
        $date = date('Y-m-d');
        $uid = $_SESSION["firstName"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';
       
        saveStockOut($conn, $id, $outstocks, $date, $uid);
        addSales($conn, $id, $deduct);

    }
    else{
        header("location: ../404.php");
        exit();
    }