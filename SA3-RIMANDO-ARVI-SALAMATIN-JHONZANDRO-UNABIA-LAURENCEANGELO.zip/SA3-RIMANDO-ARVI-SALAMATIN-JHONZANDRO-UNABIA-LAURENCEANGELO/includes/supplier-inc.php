<?php
    if(isset($_POST["btnAddSupplier"])){
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];
        $name= $_POST["name"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        createSupplier($conn, $name, $address, $email, $phone);

    }else if(isset($_POST["btnEditSupplier"])){
        $id = $_POST["id"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];
        $name= $_POST["name"];


        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        updateSupplier($conn, $id, $name, $address, $email, $phone);

    }else if(isset($_POST["btnDeleteSupplier"])){
        $id = $_POST["id"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        deleteSupplier($conn, $id);

    }
    
    else{
        header("location: ../404.php");
        exit();
    }