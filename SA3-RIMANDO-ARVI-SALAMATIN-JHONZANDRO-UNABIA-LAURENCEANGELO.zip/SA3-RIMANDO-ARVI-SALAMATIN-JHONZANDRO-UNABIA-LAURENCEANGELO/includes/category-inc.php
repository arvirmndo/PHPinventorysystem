<?php
    if(isset($_POST["btnAddCategory"])){
        $category_name = $_POST["category_name"];
        $category_desc = $_POST["category_desc"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

    //    if(uidExists($conn, $email) !== false){
    //         header("location: ../Users.php?error=usernametaken");
    //         exit(); 
    //     }

        addCategory($conn, $category_name, $category_desc);

    }else if(isset($_POST["btnEditCategory"])){
        $category_id = $_POST["category_id"];
        $category_name = $_POST["category_name"];
        $category_desc = $_POST["category_desc"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        // if(updateEmailExists($conn, $email, $uid) !== false){
        //     header("location: ../Users.php?error=usernametaken");
        //     exit(); 
        // }

        updateCategory($conn, $category_id, $category_name, $category_desc);
    }
    else{
        header("location: ../404.php");
        exit();
    }