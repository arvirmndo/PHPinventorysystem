<?php
    if(isset($_POST["cancel"])){
        session_start();
        require_once 'database-inc.php';
        require_once 'functions-inc.php';
        $id = $_POST["id"];
        $status = "Canceled";

        $total = $instock + $ordered_qty;

        
        cancelPurchaseStatus($conn, $id, $status); //update the purchase status to received in purchase table
    }
    else{
        header("location: ../404.php");
        exit();
    }