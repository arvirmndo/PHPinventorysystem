<?php
    if(isset($_POST["btnAddBrand"])){
        $brand_name = $_POST["brand_name"];
        $brand_desc = $_POST["brand_desc"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

    //    if(uidExists($conn, $email) !== false){
    //         header("location: ../Users.php?error=usernametaken");
    //         exit(); 
    //     }

        addBrand($conn, $brand_name, $brand_desc);

    }else if(isset($_POST["btnEditBrand"])){
        $brand_id = $_POST["brand_id"];
        $brand_name = $_POST["brand_name"];
        $brand_desc = $_POST["brand_desc"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        // if(updateEmailExists($conn, $email, $uid) !== false){
        //     header("location: ../Users.php?error=usernametaken");
        //     exit(); 
        // }

        updateBrand($conn, $brand_id, $brand_name, $brand_desc);
    }
    else{
        header("location: ../404.php");
        exit();
    }