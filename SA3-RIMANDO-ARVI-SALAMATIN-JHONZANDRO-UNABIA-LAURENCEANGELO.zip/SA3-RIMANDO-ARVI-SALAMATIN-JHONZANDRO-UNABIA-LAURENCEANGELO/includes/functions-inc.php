<?php
    //Validate Email
    function invalidEmail($email){
        $result;
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $result = true;
        }else{
            $result = false;
        }
        return $result;
    }

    // Check duplicate email for new user
    function uidExists($conn, $email){
        $sql = "SELECT * FROM tbusers WHERE email = ?;";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../signup.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $row;
        }else{
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    //Check duplicate email upon editing user
    function updateEmailExists($conn, $email, $uid){
        $sql = "SELECT * FROM tbusers WHERE email = ? AND NOT user_id = ?;";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Users.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $email, $uid);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $row;
        }else{
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    //check password and repeat password match
    function pwdMatch($password, $pwdRepeat){
        $result;
        if($password !== $pwdRepeat){
            $result = true;
        }else{
            $result = false;
        }
        return $result;
    }

    //validate phone number
    function validate_phone_number($phone)
    {
        // Allow +, - and . in phone number
        $filtered_phone_number = filter_var($phone, FILTER_SANITIZE_NUMBER_INT);
        // Remove "-" from number
        $phone_to_check = str_replace("-", "", $filtered_phone_number);

        // Check the lenght of number
        // This can be customized if you want phone number from a specific country
        if (strlen($phone_to_check) < 10 || strlen($phone_to_check) > 14) {
            return false;
        } else {
        return true;
        }
    }

    // Registration/Add User
    function createUser($conn, $email, $password, $first_name, $last_name, $role_id, $gender, $phone, $status){
        $sql = "INSERT INTO tbusers (email, password, firstName, lastName, role_id, gender, phoneNumber, user_status) VALUES (?,?,?,?,?,?,?,?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Users.php?error=stmtfailed");
            exit();
        }
        $hashedPwd = password_hash($password, PASSWORD_DEFAULT);

        mysqli_stmt_bind_param($stmt, "ssssssss", $email, $hashedPwd, $first_name, $last_name, $role_id, $gender, $phone, $status);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        
        header("location: ../Users.php?error=useradded");
        exit();
    }


    //Update User
    function updateUser($conn, $uid, $email, $first_name, $last_name, $role_id,$gender, $phone){
        $sql = "UPDATE tbusers SET email = ?, firstName = ?, lastName = ?, role_id = ?, gender = ?, phoneNumber = ? WHERE user_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Users.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "sssssss", $email, $first_name, $last_name, $role_id, $gender, $phone, $uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        session_start();
        if($uid == $_SESSION["userid"]){
            $_SESSION["firstName"] = $first_name;
            $_SESSION["lastName"] = $last_name;
        }

        header("location: ../Users.php?error=userupdated");
        exit();
        
    }

    //update profile
    function updateProfile($conn, $uid, $email, $first_name, $last_name, $gender, $phone){
        $sql = "UPDATE tbusers SET email = ?, firstName = ?, lastName = ?, gender = ?, phoneNumber = ? WHERE user_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../profile.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ssssss", $email, $first_name, $last_name, $gender, $phone, $uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        session_start();
        if($uid == $_SESSION["userid"]){
            $_SESSION["firstName"] = $first_name;
            $_SESSION["lastName"] = $last_name;
            $_SESSION["email"] = $email;
            $_SESSION["phone"] = $phone;
            $_SESSION["gender"] = $gender;
        }

        header("location: ../profile.php?error=profileupdated");
        exit();
        
    }

    //Change Password
    function changePwd($conn, $uid, $password, $pwdRepeat, $flag){
        $sql = "UPDATE tbusers SET password = ? WHERE user_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../changePassword.php?error=stmtfailed");
            exit();
        }

        $hashedPwd = password_hash($password, PASSWORD_DEFAULT);

        mysqli_stmt_bind_param($stmt, "ss", $hashedPwd, $uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        if($flag === "1"){
            header("location: ../users.php?error=passwordUpdated");
            exit();
        }
        else if($flag === "2"){
            header("location: ../changePassword.php?error=passwordUpdated");
            exit();
        }
       
        
    }

    // Delete User
    function deleteUser($conn, $uid){
        $sql = "DELETE FROM tbusers WHERE user_id= ?";

        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Users.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../Users.php?error=userdeleted");
        exit();
    }

     //disable user
     function disableUser($conn, $uid, $status){
        $sql = "UPDATE tbusers SET user_status = ? WHERE user_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../users.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $status, $uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../users.php?error=userdisabled");
        exit();
        
    }

    //disable user
    function activateUser($conn, $uid, $status){
        $sql = "UPDATE tbusers SET user_status = ? WHERE user_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../users.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $status, $uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../users.php?error=useractivated");
        exit();
        
    }
    //login
    function loginUser($conn, $email, $password){
        $emailExists = uidExists($conn, $email);

        if($emailExists === false){
            header("location: ../login.php?error=wronglogin");
            exit();
        }

        if($emailExists["user_status"] === "Inactive"){
            header("location: ../login.php?error=accountdisabled");
            exit();
        }

        $pwdHashed = $emailExists["password"];

        $checkPwd = password_verify($password, $pwdHashed);

        if($checkPwd === false){
            header("location: ../login.php?error=wronglogin");
            exit();
        }else if ($checkPwd === true){
            session_start();
            $_SESSION["userid"] = $emailExists["user_id"];
            $_SESSION["firstName"] = $emailExists["firstName"];
            $_SESSION["lastName"] = $emailExists["lastName"];
            $_SESSION["email"] = $emailExists["email"];
            $_SESSION["phone"] = $emailExists["phoneNumber"];
            $_SESSION["gender"] = $emailExists["gender"];
            $_SESSION["role_id"] = $emailExists["role_id"];
            header("location: ../menu.php");
            exit();
        }
    }

    //Customized role name badge
   function roleBadge($row){
       $result;
        if($row == 'Administrator'){
            $result = '<h5><span class="badge roudned-pill bg-primary text-white">'.$row.'</span></h5>';
            return $result;
        }
        else{
            $result = '<h5><span class="badge roudned-pill bg-warning text-dark">'.$row.'</span></h5>';
            return $result;
        }
   }

    //Return status name instead of status id    
   function statusName($conn, $row){
        $sql = "SELECT * FROM status WHERE status_id = ?";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Users.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $row);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $row["status_name"];
        }else{
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }
   
    // Add Group
    function addGroup($conn, $role_name){
        $sql = "INSERT INTO tbroles (role_name) VALUES (?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Groups.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "s", $role_name);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../Groups.php?error=roleadded");
        exit();
    }

    // Edit Group
    function updateGroup($conn, $role_id, $role_name){
        $sql = "UPDATE tbroles SET role_name = ? WHERE role_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Groups.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $role_name, $role_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../Groups.php?error=roleupdated");
        exit();
        
    }

    // Add Brand
    function addBrand($conn, $brand_name, $brand_desc){
        $sql = "INSERT INTO brands (brand_name, brand_desc) VALUES (?,?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Brands.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "ss", $brand_name, $brand_desc);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../Brands.php?error=brandadded");
        exit();
    }

     // Edit Group
     function updateBrand($conn, $brand_id, $brand_name, $brand_desc){
        $sql = "UPDATE brands SET brand_name = ?, brand_desc = ? WHERE brand_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Brands.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "sss", $brand_name, $brand_desc, $brand_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../Brands.php?error=brandupdated");
        exit();
    }

    // Add Category
    function addCategory($conn, $category_name, $category_desc){
        $sql = "INSERT INTO categories (category_name, category_desc) VALUES (?,?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../category.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "ss", $category_name, $category_desc);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../Category.php?error=categoryadded");
        exit();
    }

     // Edit Category
     function updateCategory($conn, $category_id, $category_name, $category_desc){
        $sql = "UPDATE categories SET category_name = ?, category_desc = ? WHERE category_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Category.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "sss", $category_name, $category_desc, $category_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../category.php?error=categoryupdated");
        exit();
        
    }

    //Add Product
    function createShoes($conn, $sku, $shoe_name, $brand_id, $category_id, $color, $size, $unitprice, $price, $stocks, $reorder){ 
        $sql = "INSERT INTO tbshoes (sku, shoe_name, brand_id, category_id, color, size, unit_price, selling_price, stocks, reorder_point) VALUES (?,?,?,?,?,?,?,?,?,?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../products.php?error=stmtfailed");
            exit();
        }
        
        
        mysqli_stmt_bind_param($stmt, "ssssssssss", $sku, $shoe_name, $brand_id, $category_id, $color, $size, $unitprice, $price, $stocks, $reorder);
        mysqli_stmt_execute($stmt);
        
        mysqli_stmt_close($stmt);
        
        header("location: ../products.php?error=productadded");
        exit();    
    }

    // Edit Product
    function updateShoes($conn, $id, $sku, $shoe_name, $brand_id, $category_id, $color, $size, $unitprice, $price, $stocks, $reorder){
        $sql = "UPDATE tbshoes SET sku = ?, shoe_name = ?, brand_id = ?, category_id = ?, color = ?, size = ?, unit_price = ?, selling_price = ?, stocks = ?, reorder_point = ? WHERE shoes_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../products.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "sssssssssss", $sku, $shoe_name, $brand_id, $category_id, $color, $size, $unitprice, $price, $stocks, $reorder, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../products.php?error=productupdated");
        exit();
    }

    // Delete Product
    function deleteProduct($conn, $id){
        $sql = "DELETE FROM tbshoes WHERE shoes_id= ?";

        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../Products.php?error=productdeleted");
        exit();
    }

    function getCategoryID($conn, $category_name){
        $sql = "SELECT * FROM categories WHERE category_name = ?";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $category_name);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $row["category_id"];
        }else{
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function getBrandID($conn, $brand_name){
        $sql = "SELECT * FROM brands WHERE brand_name = ?";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $brand_name);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $row["brand_id"];
        }else{
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function getRoleID($conn, $role_name){
        $sql = "SELECT * FROM tbroles WHERE role_name = ?";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $role_name);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $row["role_id"];
        }else{
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function addSales($conn, $id, $deduct){
        $sql = "UPDATE tbshoes SET stocks = ? WHERE shoes_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../order.php?error=stmtfailed");
            exit();
        }


        mysqli_stmt_bind_param($stmt, "ss", $deduct, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../order.php?error=salesadded");
        exit();
    }

    function getStatusLvl($conn, $stocks, $reorder){
        $result;
        if($stocks <= $reorder){
            $result = '<h5><span class="badge roudned-pill bg-warning text-white">Low Stocks</span></h5>';
            return $result;
        }
        else{
            $result = '<h5><span class="badge roudned-pill bg-success text-dark">Sufficient Stocks</span></h5>';
            return $result;
        }
    }

    function createSupplier($conn, $name, $address, $email, $phone){ 
        $sql = "INSERT INTO tbsupplier (supplier_name, supplier_address, supplier_email, supplier_phone_number) VALUES (?,?,?,?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../supplier.php?error=stmtfailed");
            exit();
        }
        
        
        mysqli_stmt_bind_param($stmt, "ssss", $name, $address, $email, $phone);
        mysqli_stmt_execute($stmt);
        
        mysqli_stmt_close($stmt);
        
        header("location: ../supplier.php?error=supplieradded");
        exit();    
    }

    function updateSupplier($conn, $id, $name, $address, $email, $phone){
        $sql = "UPDATE tbsupplier SET supplier_name =?, supplier_address=?, supplier_email=?, supplier_phone_number=? WHERE supplier_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../supplier.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "sssss", $name, $address, $email, $phone, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../supplier.php?error=supplierupdated");
        exit();
    }

    function addPurchase($conn, $id, $qty, $supplier_id, $total_amount, $date, $status){ 
        $sql = "INSERT INTO tbpurchase (shoes_id, supplier_id, qty, total_amount, order_dt, purchase_status) VALUES (?,?,?,?,?,?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../purchase.php?error=stmtfailed");
            exit();
        }
        
        
        mysqli_stmt_bind_param($stmt, "ssssss", $id, $supplier_id, $qty, $total_amount, $date, $status);
        mysqli_stmt_execute($stmt);
        
        mysqli_stmt_close($stmt);
        
        header("location: ../purchase.php?error=none");
        exit();    
    }

    function saveStockOut($conn, $id, $outstocks, $date, $uid){
        $sql = "INSERT INTO tbstock_monitoring (shoes_id, stock_out_qty, date_time, user_name) VALUES (?,?,?,?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../order.php?error=stmtfailed");
            exit();
        }
        
        
        mysqli_stmt_bind_param($stmt, "ssss", $id, $outstocks, $date, $uid);
        mysqli_stmt_execute($stmt);
        
        mysqli_stmt_close($stmt);
    }

    function saveStockIn($conn, $shoe_id, $ordered_qty, $date, $uid){
        $sql = "INSERT INTO tbstock_monitoring (shoes_id, stock_in_qty, date_time, user_name) VALUES (?,?,?,?);";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../order.php?error=stmtfailed");
            exit();
        }
        
        mysqli_stmt_bind_param($stmt, "ssss", $shoe_id, $ordered_qty, $date, $uid);
        mysqli_stmt_execute($stmt);
        
        mysqli_stmt_close($stmt);
    }

    function getInStock($conn, $shoe_id){
        $sql = "SELECT * FROM tbshoes WHERE shoes_id = ?";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $shoe_id);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $row["stocks"];
        }else{
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function addInventory($conn, $total, $shoe_id){
        $sql = "UPDATE tbshoes SET stocks = ? WHERE shoes_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../receiveOrder.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $total, $shoe_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

    }

    function updatePurchaseStatus($conn, $id, $status, $date){
        $sql = "UPDATE tbpurchase SET received_dt = ?, purchase_status = ? WHERE purchase_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../receiveOrder.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "sss", $date, $status, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../receiveOrder.php?error=POadded");
        exit();
    }

    function cancelPurchaseStatus($conn, $id, $status){
        $sql = "UPDATE tbpurchase SET purchase_status = ? WHERE purchase_id = ? ";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../receiveOrder.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $status, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../receiveOrder.php?error=POcancelled");
        exit();
    }

    function changeDateFormat($date){
        $result = '';

        if($date == ''){
            return $result;
        }else{
            $result = date(' Y/m/d', strtotime($date));
            return $result;
        }
       
    }

    // dashboard

    function getPendingPurchase($conn){
        $purchase_status = "Pending";
        $sql = "SELECT * FROM tbpurchase WHERE purchase_status = ?";
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $purchase_status);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_num_rows($resultData)){
            return $row;
        }else{
            $result = 0;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }
    
    function getCurrentMonthPurchase($conn){
        $purchase_status = "Received";
        $sql = "SELECT sum(qty) as monthlyPO from tbpurchase WHERE MONTH(order_dt) = MONTH(CURRENT_DATE()) AND YEAR(order_dt) = YEAR(CURRENT_DATE()) AND purchase_status = ?";
        
        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "s", $purchase_status);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $sum = $row['monthlyPO'];
        }else{
            $result = 0;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function getLowStock($conn){
        $sql = "SELECT * FROM `tbshoes` WHERE stocks <= reorder_point";

        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_num_rows($resultData)){
            return $row;
        }else{
            $result = 0;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }
   

    function getMonthlySales($conn){
        $sql = " SELECT sum(tbshoes.selling_price * tbstock_monitoring.stock_out_qty) as monthly_sales FROM tbshoes INNER JOIN tbstock_monitoring ON tbstock_monitoring.shoes_id = tbshoes.shoes_id";

        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../Products.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)){
            return $sum = $row['monthly_sales'];
        }else{
            $result = 0;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }