<?php
    if(isset($_POST["btnAddGroup"])){
        $role_name = $_POST["role_name"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        addGroup($conn, $role_name);

    }else if(isset($_POST["btnEditGroup"])){
        $role_id = $_POST["role_id"];
        $role_name = $_POST["role_name"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        updateGroup($conn, $role_id, $role_name);
    }
    else{
        header("location: ../404.php");
        exit();
    }