<?php
    if(isset($_POST["purchase"])){
        $id = $_POST["id"];
        $qty = $_POST["order"];
        $supplier_id = $_POST["supplier"];
        $total_amount= $_POST["total_amount"];
        $date = date('Y-m-d H:i:s');
        $status = "Pending";


        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        
        addPurchase($conn, $id, $qty, $supplier_id, $total_amount, $date, $status);
        
    }
    else{
        header("location: ../404.php");
        exit();
    }