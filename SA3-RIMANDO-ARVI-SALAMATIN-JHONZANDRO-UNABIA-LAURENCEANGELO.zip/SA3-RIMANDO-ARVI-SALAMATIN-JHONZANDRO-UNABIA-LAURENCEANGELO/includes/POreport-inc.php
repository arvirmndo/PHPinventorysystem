<?php
    require("../vendor/fpdf/fpdf.php");

    class PDF extends FPDF
    {
        function Header()
        {
            $this->Image('../img/favicon.png',10,8,33);
            $this->SetFont('Helvetica','B',16);
            $this->Cell(340,5,'KICKS RACK',0,0,'C');
            $this->Ln(10);
            $this->SetFont('Helvetica','B',14);
            $this->Cell(340,10,'Purchase Report',0,0,'C');
            $this->Ln();
        }

        function Footer()
        {
            $this->SetXY(300,-15);
            $this->SetFont('Helvetica','I',10);
            $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
            $this->Write (3, 'Created: '.date('M d Y'));
        }
        function HeaderTable(){
            $this->SetFillColor(143, 247, 247);
            $this->SetFont('Arial', 'B', '9');
            
            $this->cell(20, 10, "PO ID", 1, 0, 'C');
            $this->cell(30, 10, "SKU", 1, 0, 'C');
            $this->cell(40, 10, "Shoe Name", 1, 0, 'C');
            $this->cell(30, 10, "Color", 1, 0, 'C');
            $this->cell(15, 10, "Size (US)", 1, 0, 'C');
            $this->cell(30, 10, "Unit Price", 1, 0, 'C');
            $this->cell(20, 10, "Ordered Qty", 1, 0, 'C');
            $this->cell(30, 10, "Total Amount", 1, 0, 'C');
            $this->cell(40, 10, "Supplier", 1, 0, 'C');
            $this->cell(25, 10, "Ordered Date", 1, 0, 'C');
            $this->cell(25, 10, "Received Date", 1, 0, 'C');
            $this->cell(30, 10, "Purchase Status", 1, 1, 'C');
        }
    }

    function generatePO($conn, $option, $start, $end){
        $selected = '';
        $sql = " ";

        if($option == "Ordered Date"){
            $sql = "SELECT tbpurchase.purchase_id, tbsupplier.supplier_name, tbshoes.sku, tbshoes.shoe_name, tbshoes.color, tbshoes.size, tbshoes.unit_price, tbpurchase.qty, tbpurchase.total_amount, tbpurchase.order_dt, tbpurchase.received_dt, tbpurchase.purchase_status FROM ((tbpurchase INNER JOIN tbshoes ON tbpurchase.shoes_id = tbshoes.shoes_id) INNER JOIN tbsupplier ON tbpurchase.supplier_id = tbsupplier.supplier_id) WHERE order_dt BETWEEN ? AND ?;";
        }else{
            $sql = "SELECT tbpurchase.purchase_id, tbsupplier.supplier_name, tbshoes.sku, tbshoes.shoe_name, tbshoes.color, tbshoes.size, tbshoes.unit_price, tbpurchase.qty, tbpurchase.total_amount, tbpurchase.order_dt, tbpurchase.received_dt, tbpurchase.purchase_status FROM ((tbpurchase INNER JOIN tbshoes ON tbpurchase.shoes_id = tbshoes.shoes_id) INNER JOIN tbsupplier ON tbpurchase.supplier_id = tbsupplier.supplier_id) WHERE received_dt BETWEEN ? AND ?;";
        }

        $stmt = mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header("location: ../purchase_report.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss", $start, $end);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        
        $pdf = new PDF('p', 'mm' , 'Legal');
        
        $pdf->AddPage('L');
        $pdf->SetFont('Helvetica', '', '12');
        $pdf->Cell(340,10,changeDateFormat($start).' -'.changeDateFormat($end),0,0,'C');
        $pdf->Ln(15);

        $pdf->HeaderTable();
        
        $pdf->SetFont('Arial', '', '9');

        while($row = mysqli_fetch_assoc($resultData)){
            $pdf->cell(20, 10, $row['purchase_id'], 1, 0, 'C');
            $pdf->cell(30, 10, $row['sku'], 1, 0, 'C');
            $pdf->cell(40, 10, $row['shoe_name'], 1, 0, 'C');
            $pdf->cell(30, 10, $row['color'], 1, 0, 'C');
            $pdf->cell(15, 10, $row['size'], 1, 0, 'C');
            $pdf->cell(30, 10, $row['unit_price'], 1, 0, 'C');
            $pdf->cell(20, 10, $row['qty'], 1, 0, 'C');
            $pdf->cell(30, 10, $row['total_amount'], 1, 0, 'C');
            $pdf->cell(40, 10, $row['supplier_name'], 1, 0, 'C');
            $pdf->cell(25, 10, changeDateFormat($row['order_dt']), 1, 0, 'C');
            $pdf->cell(25, 10, changeDateFormat($row['received_dt']), 1, 0, 'C');
            $pdf->cell(30, 10, $row['purchase_status'], 1, 1, 'C');

        }

        $pdf->Output('example2.pdf','I');
    }