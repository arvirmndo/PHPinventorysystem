<?php
    if(isset($_POST["report"])){
        require_once 'database-inc.php';
        require_once 'functions-inc.php';
        require_once 'POreport-inc.php';

        $option= $_POST["search"];
        $start = date('Y-m-d', strtotime($_POST["start-date"])) ;
        $end = date('Y-m-d', strtotime($_POST["end-date"]));

        generatePO($conn, $option, $start, $end);

    }
