<?php
    if(isset($_POST["receive"])){
        session_start();
        require_once 'database-inc.php';
        require_once 'functions-inc.php';
        $id = $_POST["id"];
        $shoe_id = $_POST["shoe_id"];
        $instock = getInStock($conn, $shoe_id);
        $ordered_qty = $_POST["ordered_qty"];
        $supplier_id = $_POST["supplier"];
        $date = date('Y-m-d');
        $status = "Received";
        $uid = $_SESSION["firstName"];

        $total = $instock + $ordered_qty;

        
        addInventory($conn, $total, $shoe_id); //update inventory to add stock
        saveStockIn($conn, $shoe_id, $ordered_qty, $date, $uid); //save stock in in stock monitoring
        updatePurchaseStatus($conn, $id, $status, $date); //update the purchase status to received in purchase table
    }
    else{
        header("location: ../404.php");
        exit();
    }