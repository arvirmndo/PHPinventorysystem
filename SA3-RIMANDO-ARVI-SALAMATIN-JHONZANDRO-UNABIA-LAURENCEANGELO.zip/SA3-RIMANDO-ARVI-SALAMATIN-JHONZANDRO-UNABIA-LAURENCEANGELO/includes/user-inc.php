<?php
    if(isset($_POST["btnAdd"])){
        $email = $_POST["email"];
        $password = $_POST["password"];
        $pwdRepeat = $_POST["pwdRepeat"];
        $first_name = $_POST["first_Name"];
        $last_name = $_POST["last_Name"];
        $role_id = $_POST["role"];
        $gender = $_POST["gender"];
        $phone = $_POST["phone"];
        $status = "Active";

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        if(invalidEmail($email) !== false){
            header("location: ../Users.php?error=invalidemail");
            exit(); 
        }

        else if(uidExists($conn, $email) !== false){
            header("location: ../Users.php?error=usernametaken");
            exit(); 
        }
        else if(pwdMatch($password, $pwdRepeat) !== false){
            header("location: ../Users.php?error=passwordsdontmatch");
            exit();
        }else if (validate_phone_number($phone) != true) {
            header("location: ../Users.php?error=invalidnumber");
            exit();
         }

        createUser($conn, $email, $password, $first_name, $last_name, $role_id, $gender, $phone, $status);

    }else if(isset($_POST["btnUserUpdate"])){
        $uid = $_POST["uid"];
        $email = $_POST["email"];
        $first_name = $_POST["first_Name"];
        $last_name = $_POST["last_Name"];
        $role_name = $_POST["role"];
        $gender = $_POST["gender"];
        $phone = $_POST["phone"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

      if(updateEmailExists($conn, $email, $uid) !== false){
            header("location: ../Users.php?error=usernametaken");
            exit(); 
        }else if (validate_phone_number($phone) != true) {
            header("location: ../Users.php?error=invalidnumber");
            exit();
        }
        $role_id = getRoleID($conn, $role_name);

        updateUser($conn, $uid, $email, $first_name, $last_name, $role_id, $gender, $phone);

    }
    else if(isset($_POST["btnProfileUpdate"])){
        $uid = $_POST["uid"];
        $email = $_POST["email"];
        $first_name = $_POST["first_Name"];
        $last_name = $_POST["last_Name"];
        $gender = $_POST["gender"];
        $phone = $_POST["phone"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

      if(updateEmailExists($conn, $email, $uid) !== false){
            header("location: ../Users.php?error=usernametaken");
            exit(); 
        }else if (validate_phone_number($phone) != true) {
            header("location: ../Users.php?error=invalidnumber");
            exit();
        }
        $role_id = getRoleID($conn, $role_name);

        updateProfile($conn, $uid, $email, $first_name, $last_name, $gender, $phone);

    }else if(isset($_POST["btnUserDelete"])){
        $uid = $_POST["uid"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        deleteUser($conn, $uid);

    }else if(isset($_POST["btnUserDisable"])){
        $uid = $_POST["uid"];
        $status = "Inactive";

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        disableUser($conn, $uid, $status);

    }

    else if(isset($_POST["btnUserActivate"])){
        $uid = $_POST["uid"];
        $status = "Active";

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        activateUser($conn, $uid, $status);

    }else if(isset($_POST["btnChangePW"])){
        $uid = $_POST["uid"];
        $password = $_POST["password"];
        $pwdRepeat = $_POST["pwdRepeat"];
        $flag = $_POST["flag"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';
       
        if(pwdMatch($password, $pwdRepeat) !== false){
            if($flag == "1"){
                header("location: ../users.php?error=passwordsdontmatch");
                exit();
            }
            else if($flag == "2"){
                header("location: ../changePassword.php?error=passwordsdontmatch");
                exit();
            }
        }

        changePwd($conn, $uid, $password, $pwdRepeat, $flag); 
    }
    
    else{
        header("location: ../404.php");
        exit();
    }