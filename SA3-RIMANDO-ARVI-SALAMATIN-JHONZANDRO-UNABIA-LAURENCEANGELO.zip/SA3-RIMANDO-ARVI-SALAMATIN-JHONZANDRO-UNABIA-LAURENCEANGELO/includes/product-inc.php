<?php
     if(isset($_POST["btnAddProduct"])){
        $sku = $_POST["sku"];
        $shoe_name = $_POST["shoe_name"];
        $color = $_POST["color"];
        $brand_id = $_POST["brand"];
        $category_id = $_POST["category"];
        $size = $_POST["size"];
        $unitprice = $_POST["unit_price"];
        $price = $_POST["price"];
        $stocks = $_POST["stocks"];
        $reorder = $_POST["reorder"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';
        
        
        createShoes($conn, $sku, $shoe_name, $brand_id, $category_id, $color, $size, $unitprice, $price, $stocks, $reorder);

    }else if(isset($_POST["btnEditProduct"])){
        $id = $_POST["id"];
        $sku = $_POST["sku"];
        $shoe_name = $_POST["shoe_name"];
        $color = $_POST["color"];
        $brand_name = $_POST["brand"];
        $category_name = $_POST["category"];
        $size = $_POST["size"];
        $unitprice = $_POST["unit_price"];
        $price = $_POST["price"];
        $stocks = $_POST["stocks"];
        $reorder = $_POST["reorder"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';
        
        $brand_id = getBrandID($conn, $brand_name);
        $category_id = getCategoryID($conn, $category_name);

        updateShoes($conn, $id, $sku, $shoe_name, $brand_id, $category_id, $color, $size, $unitprice, $price, $stocks, $reorder);

    }
    else if(isset($_POST["btnProductDelete"])){
        $id = $_POST["id"];

        require_once 'database-inc.php';
        require_once 'functions-inc.php';

        deleteProduct($conn, $id);

    }else{
        header("location: ../404.php");
        exit();
    }