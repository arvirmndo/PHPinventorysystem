<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Kicks Rack - Purchases </title>
    <!-- Title icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet"> 

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="vendor/jquery-ui/jquery-ui.min.css">
    <link rel="stylesheet" href="vendor/jquery-ui/jquery-ui.theme.css">   
  
</head>

<?php 
    require_once 'includes/database-inc.php';
    include_once "header.php";
    require_once 'includes/functions-inc.php';
    
    ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Purchase Order Report</h1>
                </div>
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">List of Purchase Orders</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                        <table class = "table table-borderless mb-0" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td>
                                        <form action="includes/generatePO.php" method="post">
                                            <div class="form-group">
                                                <select class="form-select form-control form-select-md mb-3 col-lg-6 col-md-12 p-2 bg-primary text-white border-secondary search" name="search" aria-label=".form-select-lg example" required>
                                                    <option value="Ordered Date" class="bg-light text-dark">Ordered Date</option>
                                                    <option value="Received Date" class="bg-light text-dark">Received Date</option>
                                                </select>
                                            
                                            </div>
                                        
                                            <div class="row g-3">
                                                <div class="col-lg-3 mb-3">
                                                    <input type="text" class ="form-control" placeholder="Start Date" name="start-date" id="start" autocomplete="off" required>
                                                </div>
                                                <div class="col-lg-3 mb-3">
                                                    <input type="text" class ="form-control" placeholder="End Date" name="end-date" id="end" autocomplete="off" required>
                                                </div>
                                                <div class ="col-lg mb-3">
                                                    <button type="submit" id="report" name="report" class="d-sm-inline-block btn btn-sm btn-success shadow-sm p-2 col-lg-6 col-md-12 "><i
                                                    class="fas fa-download fa-sm text-white-50"></i> Generate Report</button>
                                                </div>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                        </tbody>
                    </table>
                            <table class="table table-bordered" id="POdataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>PO ID</th>
                                        <th>SKU</th>
                                        <th>Shoe Name</th>
                                        <th>Color</th>
                                        <th>Size</th>
                                        <th>Unit Price</th>
                                        <th>Ordered Qty</th>
                                        <th>Total Amount</th>
                                        <th>Supplier</th>
                                        <th>Ordered Date</th>
                                        <th>Received Date</th>
                                        <th>Purchase Status</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                <?php
                                    $query ="SELECT tbpurchase.purchase_id, tbsupplier.supplier_name, tbshoes.sku, tbshoes.shoe_name, tbshoes.color, tbshoes.size, tbshoes.unit_price, tbpurchase.qty, tbpurchase.total_amount, tbpurchase.order_dt, tbpurchase.received_dt, tbpurchase.purchase_status FROM ((tbpurchase INNER JOIN tbshoes ON tbpurchase.shoes_id = tbshoes.shoes_id) INNER JOIN tbsupplier ON tbpurchase.supplier_id = tbsupplier.supplier_id)";  
                                    $result = mysqli_query($conn, $query);
                                    
                                    if($result){
                                        foreach($result as $row )  
                                        {  
                                            echo "
                                            
                                            <tr> 
                                                <td>".$row['purchase_id']."</td>  
                                                <td>".$row['sku']."</td> 
                                                <td>".$row['shoe_name']."</td>  
                                                <td>".$row['color']."</td>  
                                                <td>".$row['size']."</td>
                                                <td>".$row['unit_price']."</td>  
                                                <td>".$row['qty']."</td>
                                                <td>".$row['total_amount']."</td>
                                                <td>".$row['supplier_name']."</td>
                                                <td>".changeDateFormat($row['order_dt'])."</td>
                                                <td>".changeDateFormat($row['received_dt'])."</td>
                                                <td>".$row['purchase_status']."</td>
                                            </tr>  
                                            ";  
                                        }  
                                    }
                                 
                                ?>  
                               
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    
    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>
    <script>
        $(document).ready(function() {
            $.fn.dataTable.ext.search.push(
            function (settings, data, dataIndex) {
                var min = $('#start').datepicker("getDate");
                var max = $('#end').datepicker("getDate");
                var select = $('.search').val();

                var orderDate = new Date(data[9]);
                var receiveDate = new Date(data[10]);
                
                if(select === "Ordered Date"){
                    if (min == null && max == null) { return true; }
                    if (min == null && orderDate <= max) { return true;}
                    if (max == null && orderDate >= min) {return true;}
                    if (orderDate <= max && orderDate >= min) { return true; }
                    return false;
                }else if(select === "Received Date"){
                    if (min == null && max == null) { return true; }
                    if (min == null && receiveDate <= max) { return true;}
                    if (max == null && receiveDate >= min) {return true;}
                    if (receiveDate <= max && receiveDate >= min) { return true; }
                    return false;
                }
               
            }
            );

            $( "#start" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy/m/d',
                onSelect: function() {
                    table.draw();}
            });
            $( "#end" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy/m/d',
                onSelect: function() {
                    table.draw();}
            });

            
            var table = $('#POdataTable').DataTable();

            $('#start, #end').change( function() {
                table.draw();
            } );

            
            $('.search').on('change', function() {
                document.getElementById('start').value = "";
                document.getElementById('end').value = "";
                table.draw();
            });
        
        } );
    </script>
</html>