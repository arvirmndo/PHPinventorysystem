<?php
    if(isset($_SESSION["role_id"])){
        if($_SESSION["role_id"] == "4"){
            include "adminHeader.php";
        }else if($_SESSION["role_id"] == "7"){
            include "cashierHeader.php";
        }else if($_SESSION["role_id"] == "5"){
            include "purchaseHeader.php";
        }
    }