<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Kicks Rack - Manage Users</title>
    <!-- Title icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
    
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        .msg {
			left: 35%;
			top: 10%;
			margin-top: -50px;
			padding: 10px; 
			border-radius: 5px; 
			color: #141314; 
			background: #e9b95f; 
			border: 1px solid #f3c324;
			width: 30%;
			text-align: center;
			position: absolute;
		}
    </style>
</head>

<?php 
    require_once 'includes/database-inc.php';
    include "header.php";
    require_once 'includes/functions-inc.php';?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Manage Users</h1>
                <p class="mb-4">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam consectetur expedita sunt aspernatur incidunt magni culpa amet commodi minima, libero nostrum dolor delectus velit suscipit voluptate obcaecati. Alias, ratione blanditiis.</p>
                <a href="#" class="btn btn-success btn-icon-split mb-4" data-toggle="modal" data-target="#addUserModal">
                    <span class="text">Add User</span>
                </a>
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Users Table</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>User ID</th>
                                        <th>Email</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Role</th>
                                        <th>Gender</th>
                                        <th>Phone Number</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                <?php
                                    $query ="SELECT tbusers.user_id, tbusers.email, tbusers.firstName, tbusers.lastName, tbusers.gender, tbusers.phoneNumber, tbusers.user_status, tbroles.role_name FROM tbusers INNER JOIN tbroles ON tbusers.role_id = tbroles.role_id ORDER BY tbusers.user_id ASC";  
                                    $result = mysqli_query($conn, $query);
                                    
                                    if($result){
                                        foreach($result as $row )  
                                        {  
                                            if($row['role_name'] === "Administrator"){
                                                echo "  
                                                <tr>  
                                                        <td>".$row['user_id']."</td>  
                                                        <td>".$row['email']."</td>  
                                                        <td>".$row['firstName']."</td>  
                                                        <td>".$row['lastName']."</td>
                                                        <td>".$row['role_name']."</td>  
                                                        <td>".$row['gender']."</td>
                                                        <td>".$row['phoneNumber']."</td>
                                                        <td>".$row['user_status']."</td>
                                                        <td><button type='button' class ='btn btn-md btn-info editUser' >Edit</button>
                                                        </td>      
                                                </tr>  
                                                ";  
                                            }else{
                                                echo "  
                                                <tr>  
                                                        <td>".$row['user_id']."</td>  
                                                        <td>".$row['email']."</td>  
                                                        <td>".$row['firstName']."</td>  
                                                        <td>".$row['lastName']."</td>
                                                        <td>".$row['role_name']."</td>  
                                                        <td>".$row['gender']."</td>
                                                        <td>".$row['phoneNumber']."</td>
                                                        <td>".$row['user_status']."</td>
                                                        <td><button type='button' class ='btn btn-md btn-info editUser' >Edit</button>
                                                        <button type='button' class ='btn btn-md btn-danger deleteUser m-1'><i class='fa fa-trash fa-sm' aria-hidden='true'></i></button>";

                                                        if($row['user_status'] === "Inactive"){
                                                            echo "<button type='button' class ='btn btn-md btn-success activateUser m-1'><i class='fa fa-chevron-up fa-sm' aria-hidden='true'></i></button>";
                                                        }else{
                                                            echo "<button type='button' class ='btn btn-md btn-warning disableUser m-1'><i class='fa fa-ban fa-sm' aria-hidden='true'></i></button>";
                                                        }
                                                        
                                                echo"   <button type='button' class ='btn btn-md btn-secondary changePwd m-1'><i class='fa fa-key fa-sm' aria-hidden='true'></i></button>  </td>      
                                                </tr>  
                                                ";  
                                            }
                                        }  
                                    }
                                 
                                ?>  
                               
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->
    
    <!--                  Users                   -->

    <!-- Add User Modal -->

    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white shadow">
                    <h5 class="modal-title" id="addUserModalLabel">Add User</h5>
                    <button type="button" class="close text-white shadow" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <form method="POST" action="includes/user-inc.php">
                        <div class="modal-body p-4">
                        <!-- <div class="form-group">
                            <label for="recipient-name" class="col-form-label">ID</label>
                            <input type="text" class="form-control" id="id" name="id">
                        </div> -->
                        <div class="form-group">
                            <label for="email" class="col-form-label">Email: </label>
                            <input type="text" class="form-control form-control-user"  name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="first_Name" class="col-form-label">First Name:</label>
                            <input type="text" class="form-control form-control-user"  name="first_Name" required>
                        </div>
                        <div class="form-group">
                            <label for="last_Name" class="col-form-label">Last Name:</label>
                            <input type="text" class="form-control form-control-user"  name="last_Name" required>
                        </div>
                        <div class="form-group">
                            <label for="phone" class="col-form-label">Phone: </label>
                            <input type="text" class="form-control form-control-user" name="phone" required>
                        </div>
                        <div class="form-group">
                            <label for="password" class="col-form-label">Password: </label>
                            <input type="password" class="form-control form-control-user" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="pwdRepeat" class="col-form-label">Repeat Password: </label>
                            <input type="password" class="form-control form-control-user" name="pwdRepeat" required>
                        </div>
                        <div class="form-group">
                            <label for="brand" class="col-form-label mr-3">Role: </label>
                            <select class="form-select form-control form-select-md mb-3 p-2 border-secondary" name="role" aria-label=".form-select-lg example" required>
                                <?php
                                    $query ="SELECT * FROM tbroles ORDER BY role_id ASC";  
                                    $result = mysqli_query($conn, $query);   
                                    while($row = mysqli_fetch_array($result))  
                                    {  
                                        echo '  
                                            <option value='.$row["role_id"].'>'.$row["role_name"].'</option>';  
                                    }  
                                ?>  
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="gender" class="col-form-label">Gender:</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender"  value="Male" autocomplete="off" checked required>
                                <label class="form-check-label" for="male">
                                    Male
                                </label>
                            </div>
                                <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender"  value="Female" autocomplete="off" required>
                                <label class="form-check-label" for="female">
                                    Female
                                </label>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
                            <button type="submit" class="btn btn-primary" name="btnAdd" value="Save">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

        <!-- Edit User Modal -->

        <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white shadow">
                    <h5 class="modal-title" id="editUserModal">Edit User</h5>
                    <button type="button" class="close text-white shadow" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <form method="POST" action="includes/user-inc.php">
                        <div class="modal-body p-4">
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">ID</label>
                            <input type="text" class="form-control uid" name="uid" readonly>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Email: </label>
                            <input type="email" class="form-control form-control-user email"  name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Last Name:</label>
                            <input type="text" class="form-control form-control-user lastName"  name="last_Name" required>
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">First Name:</label>
                            <input type="text" class="form-control form-control-user firstName"  name="first_Name" required>
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Phone: </label>
                            <input type="text" class="form-control form-control-user phone" name="phone" required>
                        </div>
                        <div class="form-group">
                            <label for="category" class="col-form-label mr-3">Role: </label> 
                            <select class="form-select form-control form-select-md  p-2 border-secondary role" name="role" aria-label=".form-select-lg example">
                                <option selected>Choose position:</option>
                                <?php
                                    $query ="SELECT * FROM tbroles ORDER BY role_id ASC";  
                                    $result = mysqli_query($conn, $query);   
                                    while($row = mysqli_fetch_array($result))  
                                    {  
                                        echo '<option value='.$row["role_name"].'>'.$row["role_name"].'</option>';  
                                    }  
                                ?>  
                                
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Gender:</label>
                        <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender"  value="Male" required>
                                <label class="form-check-label" for="male">
                                    Male
                                </label>
                            </div>
                                <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender"  value="Female" required>
                                <label class="form-check-label" for="female">
                                    Female
                                </label>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
                            <button type="submit" class="btn btn-primary" id="updateUser" name="btnUserUpdate" value="Update">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- End of Edit User Modal -->
    
    <!-- Delete User Modal-->
    <div class="modal fade" id="deleteUserModal" tabindex="-1" role="dialog" aria-labelledby="deleteUserModalLabel"
    aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white shadow">
                    <h5 class="modal-title" id="deleteUserModalLabel">Delete User?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="includes/User-inc.php" method="post">
                    <div class="modal-body">Are you sure you want to delete this user?
                        <input type="hidden" class="form-control uid" name="uid">
                        <input type="text" class="form-control username mt-3" name="username" readonly>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <input type="submit" name="btnUserDelete" class="btn btn-primary" value="Yes"></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End of Delete User Modal -->

    <!-- Disable User Modal-->
    <div class="modal fade" id="disableUserModal" tabindex="-1" role="dialog" aria-labelledby="disableUserModalLabel"
    aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-warning text-white shadow">
                    <h5 class="modal-title" id="disableUserModalLabel">Disable User?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="includes/User-inc.php" method="post">
                    <div class="modal-body">Are you sure you want to disable this user?
                        <input type="hidden" class="form-control uid" name="uid">
                        <input type="text" class="form-control username mt-3" name="username" readonly>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <input type="submit" name="btnUserDisable" class="btn btn-primary" value="Yes"></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End of Disable User Modal -->

    <!-- Activate User Modal-->
    <div class="modal fade" id="activateUserModal" tabindex="-1" role="dialog" aria-labelledby="activateUserModalLabel"
    aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-success text-white shadow">
                    <h5 class="modal-title" id="activateUserModalLabel">Activate User?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="includes/User-inc.php" method="post">
                    <div class="modal-body">Are you sure you want to activate this user?
                        <input type="hidden" class="form-control uid" name="uid">
                        <input type="text" class="form-control username mt-3" name="username" readonly>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <input type="submit" name="btnUserActivate" class="btn btn-primary" value="Yes"></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End of Activate User Modal -->

    <!-- Change Password Modal-->
    <div class="modal fade" id="passwordModal" tabindex="-1" role="dialog" aria-labelledby="passwordModalLabel"
    aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-success text-white shadow">
                    <h5 class="modal-title" id="passwordModalLabel">Change Password</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="includes/User-inc.php" method="post">
                    <div class="modal-body">
                        <input type="hidden" class="form-control uid" name="uid">
                        <input type="hidden" class="form-control flag" name="flag" value="1">
                        <div class="form-group">
                            <label for="password" class="col-form-label">Password: </label>
                            <input type="password" class="form-control form-control-user" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="pwdRepeat" class="col-form-label">Repeat Password: </label>
                            <input type="password" class="form-control form-control-user" name="pwdRepeat" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <input type="submit" name="btnChangePW" class="btn btn-primary" value="Yes"></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End of Change Password Modal -->
    
    <?php
        if(isset($_GET["error"])){
            if($_GET["error"] == "invalidemail"){ ?>
                <div class='msg'>
                    <?php echo "Email is invalid!"; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "stmtfailed"){ ?>
                <div class='msg'>
                    <?php echo "Oops! Something went wrong."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "useradded"){ ?>
                <div class='msg'>
                    <?php echo "User account has been added successfully."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "userupdated"){ ?>
                <div class='msg'>
                    <?php echo "User account has been updated successfully."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "userdeleted"){ ?>
                <div class='msg'>
                    <?php echo "User account has been deleted successfully."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "userdisabled"){ ?>
                <div class='msg'>
                    <?php echo "User account has been disabled successfully."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "useractivated"){ ?>
                <div class='msg'>
                    <?php echo "User account has been activated successfully."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "usernametaken"){ ?>
                <div class='msg'>
                    <?php echo "Username already exists."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "passwordsdontmatch"){ ?>
                <div class='msg'>
                    <?php echo "Password does not match."; ?>          
                </div>
                <?php
            }else if($_GET["error"] == "invalidnumber"){?>
                <div class='msg'>
                    <?php echo "Invalid phone number"; ?>          
                </div>
                <?php
            }
        }
    ?>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script>
        $(document).ready(function(){
            $('.editUser').click(function(){  
                $("#editUserModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#editUserModal .uid').val(data[0]);
                $('#editUserModal .email').val(data[1]);
                $('#editUserModal .firstName').val(data[2]);
                $('#editUserModal .lastName').val(data[3]);
                $('#editUserModal .role').val(data[4]);
                $("#editUserModal input[name=gender][value=" + data[5] + "]").prop('checked',true);
                $('#editUserModal .phone').val(data[6]);
               
            });
            $('.deleteUser').click(function(){  
                $("#deleteUserModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#deleteUserModal .uid').val(data[0]);
                $('#deleteUserModal .username').val(data[2] + ' ' + data[3]);
               
            });

            $('.disableUser').click(function(){  
                $("#disableUserModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#disableUserModal .uid').val(data[0]);
                $('#disableUserModal .username').val(data[2] + ' ' + data[3]);
               
            });

            $('.activateUser').click(function(){  
                $("#activateUserModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#activateUserModal .uid').val(data[0]);
                $('#activateUserModal .username').val(data[2] + ' ' + data[3]);
               
            });

            $('.changePwd').click(function(){  
                $("#passwordModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#passwordModal .uid').val(data[0]);
               
            });
                  
          });
    </script>
    <script>
        setTimeout(function() {
            $('.msg').fadeOut('fast');
        }, 3000); // <-- time in milliseconds
    </script>
</body>

</html>