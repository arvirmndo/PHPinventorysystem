<?php
    session_start();
    if(!isset($_SESSION["firstName"])){
        header("location: 404.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Kicks Rack - Manage Category</title>

    <!-- Title icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
        .msg {
			left: 35%;
			top: 10%;
			margin-top: -50px;
			padding: 10px; 
			border-radius: 5px; 
			color: #141314; 
			background: #e9b95f; 
			border: 1px solid #f3c324;
			width: 30%;
			text-align: center;
			position: absolute;
		}
    </style>

</head>

    <?php 
        require_once 'includes/database-inc.php'; 
        include_once "header.php";
    ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Manage Category</h1>
                <p class="mb-4">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet incidunt eos distinctio delectus perspiciatis pariatur blanditiis, suscipit repellat deserunt ex, molestias non unde corrupti cum natus sed repellendus minima culpa.</p>
                <a href="#" class="btn btn-success btn-icon-split mb-4" data-toggle="modal" data-target="#addCategoryModal">
                    <span class="text">Add Category</span>
                </a>

                <!-- DataTables Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Category ID</th>
                                        <th>Category Name</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $query ="SELECT * FROM categories ORDER BY category_id ASC";  
                                    $result = mysqli_query($conn, $query);   
                                    while($row = mysqli_fetch_array($result))  
                                    {  
                                        echo '  
                                        <tr>  
                                                <td>'.$row["category_id"].'</td>  
                                                <td>'.$row["category_name"].'</td>
                                                <td>'.$row["category_desc"].'</td>  
                                                <td><button type="button" class ="btn btn-md btn-info editCategory" >Edit</button>
                                                </td>      
                                        </tr>  
                                        ';  
                                    }  
                                ?>  
                                   
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!--    Category Modals    -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white shadow">
                    <h5 class="modal-title" id="addCategoryModalLabel">Add Category</h5>
                    <button type="button" class="close text-white shadow" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <form method="POST" action="includes/category-inc.php">
                        <div class="modal-body p-4">
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Category Name: </label>
                            <input type="text" class="form-control form-control-user"  name="category_name" required>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Description: </label>
                            <input type="textarea" class="form-control form-control-user"  name="category_desc" placeholder="Add description here..." required>
                        </div>
                        
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
                            <button type="submit" class="btn btn-primary" name="btnAddCategory" value="Save">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white shadow">
                    <h5 class="modal-title" id="editCategoryModalLabel">Add Category</h5>
                    <button type="button" class="close text-white shadow" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <form method="POST" action="includes/category-inc.php">
                        <div class="modal-body p-4">
                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Category Name: </label>
                                <input type="text" class="form-control form-control-user category_id"  name="category_id" readonly>
                            </div>
                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Category Name: </label>
                                <input type="text" class="form-control form-control-user category_name"  name="category_name" required>
                            </div>
                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Description: </label>
                                <input type="textarea" class="form-control form-control-user category_desc"  name="category_desc" placeholder="Add description here..." required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
                            <button type="submit" class="btn btn-primary" name="btnEditCategory" value="update">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>                                             
    <!-- End of Category modal -->

    <?php
        if(isset($_GET["error"])){
            if($_GET["error"] == "stmtfailed"){ ?>
                <div class='msg'>
                    <?php echo "Oops! Something went wrong."; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "categoryadded"){ ?>
                <div class='msg'>
                    <?php echo "Category has been added successfully"; ?>          
                </div>
                <?php
            }
            else if($_GET["error"] == "categoryupdated"){ ?>
                <div class='msg'>
                    <?php echo "Category has been updated successfully."; ?>          
                </div>
                <?php
            }
        }
    ?>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script>
        $(document).ready(function(){
            $('.editCategory').click(function(){  
                $("#editCategoryModal").modal('show');
                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();

                console.log(data);
                $('#editCategoryModal .category_id').val(data[0]);
                $('#editCategoryModal .category_name').val(data[1]);
                $('#editCategoryModal .category_desc').val(data[2]);
               
            });
            // $('.deleteUser').click(function(){  
            //     $("#deleteUserModal").modal('show');
            //     $tr = $(this).closest('tr');

            //     var data = $tr.children("td").map(function(){
            //         return $(this).text();
            //     }).get();

            //     console.log(data);
            //     $('#deleteUserModal .uid').val(data[0]);
            //     $('#deleteUserModal .username').val(data[2] + ' ' + data[3]);
               
            // });      
          });
    </script>
     <script>
        setTimeout(function() {
            $('.msg').fadeOut('fast');
        }, 3000); // <-- time in milliseconds
    </script>
</body>

</html>